﻿module HeapSelector
open System
open System.Windows.Forms
open System.Drawing
//This moduler is used when the user wants to pick the amount of heaps

let OkButton =
  new Button(Location=Point(50,65),MinimumSize=Size(100,50),
              MaximumSize=Size(100,50),Text="Ok", Visible=true)

//let intButton





